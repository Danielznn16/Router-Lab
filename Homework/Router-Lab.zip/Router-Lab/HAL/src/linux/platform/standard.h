#include "router_hal.h"

const char *interfaces[N_IFACE_ON_BOARD] = {
    "veth-R2-1",
    "veth-R2-2",
    "eth3",
    "eth4",
};
